import logging

logging = logging.getLogger(__name__)


class DataProcess:
    def __init__(self) -> None:
        logging.info("Data Processing module")
