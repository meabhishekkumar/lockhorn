import logging

logging = logging.getLogger(__name__)


class SchemaBuilder:
    def __init__(self) -> None:
        logging.info("schema builder process")
