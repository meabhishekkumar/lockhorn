import logging

logging = logging.getLogger(__name__)


class Process:
    def __init__(self) -> None:
        logging.info("processing phase")
